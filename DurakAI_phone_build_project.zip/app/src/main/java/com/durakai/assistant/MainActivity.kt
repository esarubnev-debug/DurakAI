package com.durakai.assistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,36,28,24) }
        root.addView(TextView(this).apply { text="Durak AI Assistant"; textSize=26f })
        root.addView(TextView(this).apply {
            text="Помощник для игры в дурака\\n\\nПлавающая панель показывает рекомендацию. Пока карты вводятся вручную: автоматическое распознавание графических карт этой версии ещё не реализовано."
            textSize=16f
        })
        root.addView(Button(this).apply {
            text="Разрешить плавающее окно"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity))
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                else Toast.makeText(this@MainActivity,"Разрешение уже есть",Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text="Показать плавающую панель"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) startService(Intent(this@MainActivity,OverlayService::class.java))
                else Toast.makeText(this@MainActivity,"Сначала выдай разрешение",Toast.LENGTH_LONG).show()
            }
        })
        root.addView(Button(this).apply {
            text="Скрыть панель"
            setOnClickListener { stopService(Intent(this@MainActivity,OverlayService::class.java)) }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
