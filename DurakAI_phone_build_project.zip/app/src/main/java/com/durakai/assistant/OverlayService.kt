package com.durakai.assistant

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*

class OverlayService:Service(){
    private lateinit var wm:WindowManager
    private var panel:View?=null
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        if(panel!=null)return START_NOT_STICKY
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val box=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;setPadding(14,12,14,12);setBackgroundColor(0xF5FFFFFF.toInt())
        }
        val header=TextView(this).apply{text="☰ DURAK AI  •  перетащи";textSize=15f;setTextColor(0xFF172033.toInt())}
        box.addView(header)
        val hand=EditText(this).apply{hint="Твои карты: 10♠ 9♣ 6♦";textSize=13f}
        val table=EditText(this).apply{hint="Стол: 8♦ или первый ход";textSize=13f}
        val trump=EditText(this).apply{hint="Козырь: ♠ ♥ ♦ ♣";textSize=13f}
        box.addView(hand);box.addView(table);box.addView(trump)
        val result=TextView(this).apply{text="Заполни поля и нажми «Анализ».";textSize=14f;setTextColor(0xFF126B35.toInt())}
        box.addView(Button(this).apply{text="Найти лучший ход";setOnClickListener{
            result.text=DurakLogic.advise(hand.text.toString(),table.text.toString(),trump.text.toString(),"")
        }})
        box.addView(result)
        box.addView(Button(this).apply{text="Закрыть";setOnClickListener{stopSelf()}})
        val p=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.END;x=12;y=120}
        header.setOnTouchListener(object:View.OnTouchListener{
            var sx=0f;var sy=0f;var ox=0;var oy=0
            override fun onTouch(v:View,e:MotionEvent):Boolean{
                when(e.action){
                    MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=p.x;oy=p.y;return true}
                    MotionEvent.ACTION_MOVE->{p.x=(ox-(e.rawX-sx)).toInt();p.y=(oy+(e.rawY-sy)).toInt();wm.updateViewLayout(box,p);return true}
                };return false
            }
        })
        wm.addView(box,p);panel=box;return START_NOT_STICKY
    }
    override fun onDestroy(){panel?.let{wm.removeView(it)};panel=null;super.onDestroy()}
}
