package com.durakai.assistant

data class Card(val rank:Int, val suit:Char) {
    override fun toString() = "${listOf("6","7","8","9","10","В","Д","К","Т")[rank]}$suit"
}
object DurakLogic {
    private val ranks = listOf("6","7","8","9","10","В","Д","К","Т")
    private val suits = "♠♥♦♣"
    fun parse(text:String):List<Card> {
        val re=Regex("(10|[6-9]|В|Д|К|Т)\\s*([♠♥♦♣])", RegexOption.IGNORE_CASE)
        return re.findAll(text.uppercase()).mapNotNull {
            val r=ranks.indexOf(it.groupValues[1])
            val s=it.groupValues[2].firstOrNull()
            if(r>=0 && s!=null && s in suits) Card(r,s) else null
        }.toList()
    }
    fun advise(handText:String, tableText:String, trumpText:String, mode:String):String {
        val hand=parse(handText).distinct()
        val table=parse(tableText)
        val trump=trumpText.trim().firstOrNull()
        if(hand.isEmpty()) return "Не вижу карт в руке. Пример: 10♠ 9♣ 6♦"
        if(trump !in suits) return "Укажи козырь: ♠ ♥ ♦ ♣"
        if(table.isEmpty()) return "Укажи карту(ы) на столе. Для первого хода укажи «первый ход»."
        if(tableText.contains("первый ход",true)) {
            val nonTrump=hand.filter{it.suit!=trump}.minByOrNull{it.rank}
            val choice=nonTrump ?: hand.minBy{it.rank}
            return "Первый ход: $choice\\nОбычно выгодно начинать с младшей некозырной карты."
        }
        val target=table.last()
        val defending=hand.filter { c ->
            (c.suit==target.suit && c.rank>target.rank) ||
            (c.suit==trump && target.suit!=trump)
        }.sortedWith(compareBy<Card>{if(it.suit==trump) 1 else 0}.thenBy{it.rank})
        if(defending.isEmpty()) return "Отбиться нечем. Рекомендация: брать карты."
        val c=defending.first()
        return "Отбиться: $c\\nВыбрана самая младшая подходящая карта, чтобы сохранить старшие."
    }
}
